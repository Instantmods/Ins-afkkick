fx_version 'cerulean'
game 'gta5'

author 'Instant Mods'
description ''
version '1.0.0'

server_script 'server.lua'
client_script 'client.lua'
