local afkTimeLimit = 600 -- AFK time limit in seconds (10 minutes)
local checkInterval = 90 -- Time interval to check for AFK players in seconds (1 minute 30 Sec)

local playerActivity = {}

local function kickAFKPlayers()
    for playerId, lastActivity in pairs(playerActivity) do
        if os.time() - lastActivity > afkTimeLimit then
            DropPlayer(playerId, "You have been kicked for being AFK too long.")
            playerActivity[playerId] = nil
        end
    end
end

RegisterServerEvent('afk_kick:playerActive')
AddEventHandler('afk_kick:playerActive', function()
    local playerId = source
    playerActivity[playerId] = os.time()
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(checkInterval * 1000)
        kickAFKPlayers()
    end
end)

AddEventHandler('playerDropped', function()
    local playerId = source
    playerActivity[playerId] = nil
end)
