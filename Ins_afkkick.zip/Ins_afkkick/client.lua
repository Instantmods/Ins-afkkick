local activityInterval = 30 

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(activityInterval * 1000)
        TriggerServerEvent('afk_kick:playerActive')
    end
end)
